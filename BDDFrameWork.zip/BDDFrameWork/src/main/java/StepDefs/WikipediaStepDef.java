package StepDefs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import Java.WikipediaPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class WikipediaStepDef {
	
	public static WebDriver driver=null;
	public static WikipediaPage wikipediaPage;
	
	
	public WikipediaStepDef()
	{
		driver=Hooks.driver;
		wikipediaPage=PageFactory.initElements(driver, WikipediaPage.class);
	}
	
	@Given("^user launch the Browser and navigate to Wikipedia site$")
	public void user_launch_the_Browser_and_navigate_to_Wikipedia_site() throws Throwable {
		wikipediaPage.navigateToWikipediaSite();
	}

	@Then("^user verifies Wikipedia link is valid or not valid and scrape the links into excel$")
	public void user_verifies_Wikipedia_link_is_valid_or_not_valid_and_scrape_the_links_into_excel() throws Throwable {
	  wikipediaPage.verifyWikipediaLink();
	}


}
