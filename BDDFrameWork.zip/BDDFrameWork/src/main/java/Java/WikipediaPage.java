package Java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WikipediaPage {

public static WebDriver driver;
String homepage = "https://www.wikipedia.org/";
String url = "";
HttpURLConnection huc = null;
int respCode = 200;


public WikipediaPage(WebDriver driver) {
	  this.driver = driver;
	  
}


public void navigateToWikipediaSite() {
	driver.get(homepage);
	
}
public void verifyWikipediaLink() throws IOException
{
	 File src = new File("C:\\Users\\ADMIN\\eclipse-workspace\\BDDFrameWork\\ConfigUtility\\WikipediaLinks.xlsx");
     FileInputStream fis = new FileInputStream(src);
     XSSFWorkbook wb = new XSSFWorkbook(fis);
     XSSFSheet Sheet1 = wb.getSheetAt(0);
     Sheet1.createRow(0).createCell(0);
     List<WebElement> links=driver.findElements(By.tagName("a"));
     int cell =0;
     for(int i=0;i<links.size();i++) {
         WebElement alinks = links.get(i);
         String allinks = alinks.getAttribute("href");
         System.out.println(allinks);
         XSSFRow row = Sheet1.createRow(i);
         XSSFCell excelCell = row.createCell(cell);
         excelCell.setCellValue(allinks);

     }
      Iterator<WebElement> it = links.iterator();
      while(it.hasNext()){
        url = it.next().getAttribute("href");
        System.out.println(url);
        if(url == null || url.isEmpty()){
         System.out.println("URL is not yet published");
                         continue;
                     }
        try {
            huc = (HttpURLConnection)(new URL(url).openConnection());

            huc.setRequestMethod("HEAD");

            huc.connect();

            respCode = huc.getResponseCode();
            for (int i=1; i <= Sheet1.getLastRowNum(); i++){
                Cell resultCell= Sheet1.getRow(i).getCell(1); 

            if(respCode >= 400){
                System.out.println(url+" is a broken link");
                resultCell.setCellValue("FAIL");
            }
            else{
                System.out.println(url+" is a valid link");
                resultCell.setCellValue("PASS");
            }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     FileOutputStream fout = new FileOutputStream(src);
     wb.write(fout);
 }
}

	
	
	